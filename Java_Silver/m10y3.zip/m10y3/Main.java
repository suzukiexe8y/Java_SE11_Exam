//import m10y3.se10y3;

public class Main {
  public static void main(String[] args){
    try{
      sample();
      sub();
    } catch (sse10y3 e){
      System.out.println("C");
    } catch  (se10y3 e){
      System.out.println("A");
    } 
    // catch (sse10y3 e){
    //   System.out.println("B");
    // }
    /* 
    error: exception sse10y3 has already been caught
     */

    ///output A

  }

  private static void sample() throws se10y3{
    throw new se10y3();
  }

  private static void sub() throws sse10y3{
    throw new sse10y3();
  }
}