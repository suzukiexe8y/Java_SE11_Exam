public class se10y3 extends Exception{
  
}
